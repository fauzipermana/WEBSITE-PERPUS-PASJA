<?php
	require "functions_buku.php";
	$buku = query ("SELECT * FROM buku");

	//tekan tombol cari
	if (isset($_POST["cari"])) {
		$buku = cari($_POST["keyword"]);
	}
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(tambah($_POST) > 0){
			echo "
					<script>
						alert('data berhasil ditambahkan');
						document.location.href='buku.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal ditambahkan');
						document.location.href='buku.php';
					</script>
			";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>buku</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">

</head>
<body>
	
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo.gif"></div>
		 	<ul>
		 		<li><a href="home2.php">Home</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 </div>
		 <div class="title">
		 	<h1>Perpustakaan SMK Pasundan Jatinangor</h1>
		 </div>
	</header>

	<div class="container">
	
	<!-- selesai card form -->

	<!-- pencarian -->
	<form action="#" method="post">
		<div class="input-group mb-3"> 
		<input type="text" name="keyword" size="40" autofocus placeholder="Masukkan kata pencarian..." autocomplete="off" id="keyword" class="form-control">
			<div class="input-group-append">
				<button type="submit" name="cari" id="tombolcari" class="btn btn-warning">Cari</button>
			</div>
		</div>
	</form>

	<!-- awalcard tabel .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header text-white bg-success text-center lead">
	    DATA BUKU
	  </div>
	  <div class="card-body">
	  	<table class="table table-bordered table-striped">
	  		<tr class=" text-dark text-center">
	  			<th class="text-center">No</th>
	  			<th class="text-center">Id Buku</th>
	  			<th class="text-center">Pengarang</th>
	  			<th class="text-center">Judul Buku</th>
	  			<th class="text-center">Cetakan</th>
	  			<th class="text-center">Tahun Terbit</th>
	  			<th class="text-center">Penerbit</th>
				<th class="text-center">Asal Buku</th>
	  			<th class="text-center">Harga</th>
				  <th class="text-center">Keterangan</th>


	  		</tr>
	  		<?php $i = 1; ?>
	  		<?php foreach ($buku as $row) :	?> 
	  		<tr>
	  			<td><?=$i; ?></td>
	  			<td><?=$row["id_buku"]?></td>
	  			<td><?=$row["judul_buku"]?></td>
	  			<td><?=$row["penulis_buku"]?></td>
	  			<td><?=$row["penerbit_buku"]?></td>
	  			<td><?=$row["tahun_terbit"]?></td>
	  			<td><?=$row["stok"]?></td>
	  			<td>
	  			</td>
	  		</tr>
	  		<?php $i++;?>
	  		<?php endforeach; ?>
	  	</table>
	  </div>
	</div>
	<!-- selesai card tabel -->
	</div>
	<footer>
		Copyright &copy; 2023 || by Muhamad Fauzi Permana SI M'U 2023
    </footer>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>