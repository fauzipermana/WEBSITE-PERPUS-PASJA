<?php
	require "functions_user.php";
	$id_user = $_GET["id_user"];
	$mb = query("SELECT * FROM user WHERE id_user$id_user")[0];

	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='user.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='user.php';
					</script>
			";
		}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>user</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-success text-white text-center lead">
	    FORM EDIT DATA USER
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
            <label class="text-success lead">id_user</label>
	  		<input type="text" id_user="id_user" value="<?=$mb["id_user"]; ?>">
	  		<div class="form-group">
	  			<label class="text-success lead">username</label>
	  			<input type="text" password="password" class="form-control" value="<?=$mb["password"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">level</label>
	  			<input type="text" name="level" class="form-control" value="<?=$mb["level"];?>" required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
	<footer>
		Copyright &copy; 2020 || by Ismi Dzikrina Informatika
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>