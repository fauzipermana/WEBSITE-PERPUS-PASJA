<?php 
//koneksi ke database
$conn = mysqli_connect("localhost","root","","perpus_20");

 function query($query){
 	global $conn;
	 $result = mysqli_query($conn,$query);
	$rows = [];
	while ($row = mysqli_fetch_array($result)) {
	 	$rows[] = $row;
	} 
	return $rows;
}

function tambah($data){
	global $conn;
	//ambil semua data yang dikirim
	// $kode_buku = htmlspecialchars($data["kode_buku"]);
	$id_buku =$data["id_buku"];
	$pengarang = htmlspecialchars($data["pengarang"]);
	$judul_buku = htmlspecialchars($data["judul_buku"]);
	$cetakan = htmlspecialchars($data["cetakan"]);
	$tahun_terbit = htmlspecialchars($data["tahun_terbit"]);
	$penerbit_buku = htmlspecialchars($data["penerbit"]);
	$asal_buku = htmlspecialchars($data["asal_buku"]);
	$harga = htmlspecialchars($data["harga"]);
	$keterangan = htmlspecialchars($data["keterangan"]);


	//insert data ke dalam db
	$query = "INSERT INTO buku VALUES ('$id_buku','$pengarang','$judul_buku','$cetakan','$tahun_terbit','$penerbit_buku','$asal_buku','$harga','$keterangan')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
}

function hapus($id_buku){
	global $conn;
	mysqli_query($conn,"DELETE FROM buku WHERE id_buku='$id_buku'");
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_buku =$data["id_buku"];
	$pengarang = htmlspecialchars($data["pengarang"]);
	$judul_buku = htmlspecialchars($data["judul_buku"]);
	$cetakan = htmlspecialchars($data["cetakan"]);
	$tahun_terbit = htmlspecialchars($data["tahun_terbit"]);
	$penerbit = htmlspecialchars($data["penerbit"]);
	$asal_buku = htmlspecialchars($data["asal_buku"]);
	$harga = htmlspecialchars($data["harga"]);
	$keterangan = htmlspecialchars($data["keterangan"]);

	//update data ke dalam db
	$query = "UPDATE buku SET
					id_buku='$id_buku',
					pengarang='$pengarang,
					judul_buku='$judul_buku',
					cetakan= '$cetakan',
					tahun_terbit='$tahun_terbit',
					penerbit ='$penerbit',
					asal_buku= '$asal_buku',
					harga= '$harga',
					keterangan= '$keterangan',
			WHERE id_buku='$id_buku'
			";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);	
}

function cari($keyword){
	$query = "SELECT * FROM buku WHERE id_buku LIKE '%$keyword%' OR judul_buku LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' OR penerbit LIKE '%$keyword%' OR tahun_terbit LIKE '%$keyword%' OR  LIKE '%$keyword%'";
	return query($query);
}
?>