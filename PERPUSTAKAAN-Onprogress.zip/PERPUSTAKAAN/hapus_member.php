<?php
//cek untuk tombol hapus
	require "functions_member.php";
	$id_member=$_GET["id_member"];
	if (hapus($id_member)>0) {
		echo "
					<script>
						alert('data berhasil dihapus');
						document.location.href='member.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal dihapus');
						document.location.href='member.php';
					</script>
			";
	}

?>