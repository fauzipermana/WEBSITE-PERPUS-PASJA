<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
	function __construct(){
	 parent::__construct();
	 	//validasi jika user belum login
     $this->data['CI'] =& get_instance();
     $this->load->helper(array('form', 'url'));
     $this->load->model('M_Admin');
     	if($this->session->userdata('masuk_perpus') != TRUE){
			$url=base_url('login');
			redirect($url);
		}
     }
     
    public function anggota()
    {	
        $this->data['idbo'] = $this->session->userdata('ses_id');
        $this->data['user'] = $this->M_Admin->get_tableid('tbl_login','level','Anggota');
        $this->data['title_web'] = 'Laporan Data Anggota';
        $this->load->view('header_view',$this->data);
        $this->load->view('sidebar_view',$this->data);
        $this->load->view('laporan/anggota_view',$this->data);
        $this->load->view('footer_view',$this->data);
    }
	public function buku()
    {	
        $this->data['idbo'] = $this->session->userdata('ses_id');
        $this->data['buku'] =  $this->db->query("SELECT * FROM tbl_buku JOIN tbl_kategori ON tbl_buku.id_kategori=tbl_kategori.id_kategori ORDER BY id_buku DESC");
        $this->data['title_web'] = 'Laporan Data Buku';
        $this->load->view('header_view',$this->data);
        $this->load->view('sidebar_view',$this->data);
        $this->load->view('laporan/buku_view',$this->data);
        $this->load->view('footer_view',$this->data);
    }

	public function transaksi()
    {	
        $this->data['idbo'] = $this->session->userdata('ses_id');
        $this->data['transaksi'] =  $this->db->query("SELECT * FROM tbl_pinjam JOIN tbl_buku ON tbl_pinjam.buku_id=tbl_buku.buku_id JOIN tbl_login ON tbl_pinjam.anggota_id=tbl_login.anggota_id ORDER BY tbl_pinjam.pinjam_id DESC");
        $this->data['title_web'] = 'Laporan Transaksi';
        $this->load->view('header_view',$this->data);
        $this->load->view('sidebar_view',$this->data);
        $this->load->view('laporan/transaksi_view',$this->data);
        $this->load->view('footer_view',$this->data);
    }

    
}
