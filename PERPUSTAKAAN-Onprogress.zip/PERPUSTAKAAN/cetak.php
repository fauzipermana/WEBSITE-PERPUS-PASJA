<html>
<head>
	<title>Data Laporan Transaksi</title>
</head>
<body>
 
	<center>
 
		<h3><font face="Arial">Data Laporan Transaksi</font></h3>
		<h2><font face="Arial">Perpustakaan Sukoharjo</font></h2>

	</center>
 
	<?php 
	$conn = mysqli_connect("localhost","root","","perpus_20");

	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="5%">No</th>
			<th>Id Member</th>
			<th>Id Buku</th>
			<th>Tanggal Pinjam</th>
			<th>Tanggal Kembali</th>
			<th>Status</th>
		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($conn,"SELECT * FROM transaksi");
		while($row = mysqli_fetch_assoc($sql)){
		?>
		<tr>
			 <td><?php echo $no++;?></td>
             <td><?php echo $row['id_member'];?></td>
             <td><?php echo $row['id_buku'];?></td>
             <td><?php echo $row['tgl_pinjam'];?></td>
             <td><?php echo $row['tgl_kembali'];?></td>
             <td><?php echo $row['status'];?></td>
		</tr>
		<?php } ?>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>
