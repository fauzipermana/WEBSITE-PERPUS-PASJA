<?php
	require "functions_transaksi.php";
	$id_transaksi = $_GET["id_transaksi"];
	$tr = query("SELECT * FROM transaksi WHERE id_transaksi=$id_transaksi")[0];

	
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='transaksi.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
					</script>
			";
		}
		}
?>

<!DOCTYPE html>
<html>
<head>
	<title>transaksi</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-success text-white text-center lead">
	    FORM EDIT DATA TRANSAKSI PEMINJAMAN & PENGEMBALIAN
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<input type="hidden" name="id_transaksi" value="<?=$tr["id_transaksi"]; ?>">
	  		
	  		<div class="form-group">
	  			<label class="text-success lead">Id Member</label>
	  			<input type="text" class="form-control" name="id_member" readonly value="<?=$tr["id_member"];?>" required/>	  			
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Id Buku</label>
	  			<input type="text" class="form-control" name="id_buku" readonly value="<?=$tr["id_buku"];?>" required/>	  
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Tanggal Peminjaman</label>
	  			<input type="date" name="tgl_pinjam" class="form-control" value="<?=$tr["tgl_pinjam"];?>" required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="text-success lead">Tanggal Kembalian</label>
	  			<input type="date" name="tgl_kembali" class="form-control" value="<?=$tr["tgl_kembali"];?>">
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Status</label>
	  			<input type="text" name="status" class="form-control" value="<?=$tr["status"];?>">
	  		</div>
	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
	<footer>
		Copyright &copy; 2023 || by Muhamad Fauzi Permana SI M'U 2023
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>