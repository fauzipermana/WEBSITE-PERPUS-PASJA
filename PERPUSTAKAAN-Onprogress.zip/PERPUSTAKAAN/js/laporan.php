<?php
// Koneksi ke database
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "nama_database";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data dari tabel perpustakaan
$sql = "SELECT * FROM perpustakaan";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Membuat tabel laporan
    echo "<table>
            <tr>
                <th>ID Buku</th>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th>Penerbit</th>
            </tr>";
    
    // Mengisi data pada tabel laporan
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row["id_buku"]."</td>
                <td>".$row["judul_buku"]."</td>
                <td>".$row["pengarang"]."</td>
                <td>".$row["penerbit"]."</td>
            </tr>";
    }
    
    echo "</table>";
} else {
    echo "Tidak ada data yang ditemukan";
}

$conn->close();
?>
