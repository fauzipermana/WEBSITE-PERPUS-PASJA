<?php
	require "functions_buku.php";
	$id_buku = $_GET["id_buku"];
	$bk = query("SELECT * FROM buku WHERE id_buku=$id_buku")[0];

	$query = "SELECT * FROM buku";
	$result = mysqli_query($conn,$query);

	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='buku.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='buku.php';
					</script>
			";
		}
		}
?>
<!-- //  -->
<!DOCTYPE html>
<html>
<head>
	<title>buku</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-success text-white text-center lead">
	    FORM EDIT DATA BUKU
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<div class="form-group">
	  			<label class="text-success lead">Id Buku</label>
	  			<input type="text" name="id_buku" class="form-control" readonly value="<?=$bk["id_buku"];?>" required/>
	  		</div>
			  <div class="form-group">
   			<label class="text-success lead" for="pengarang_buku">Pengarang</label>
			<input type="text" name="judul_buku" class="form-control" value="<?=$bk["judul_buku"]; ?>" required/>
			</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Judul Buku</label>
	  			<input type="text" name="judul_buku" class="form-control" value="<?=$bk["judul_buku"]; ?>" required/>
	  		</div>
			  <div class="form-group">
	  			<label class="text-success lead">Cetakan</label>
	  			<input type="text" name="cetakan" class="form-control" value="<?=$bk["cetakan"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Tahun Terbit</label>
	  			<input type="number" name="tahun_terbit" min="2000" max="2020" class="form-control" value="<?=$bk["tahun_terbit"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Penerbit</label>
	  			<input type="text" name="penerbit" class="form-control" value="<?=$bk["penerbit"]; ?>" required/>
	  		</div>
			  <div class="form-group">
    <label class="text-success lead" for="asal_buku">Asal Buku</label>
    <select name="asal_buku" id="asal_buku" class="form-control" required>
        <option value="">Pilih Asal Buku</option>
        <option value="Gratis">Gratis</option>
        <option value="Pembelian">Pembelian</option>
        <option value="Penukaran">Penukaran</option>
    </select>
	</div>
			  <label class="text-success lead">Harga</label>
			  <input type="number" name="harga" class="form-control" value="Masukkan harga buku disini...." optional>	  		
			</div>
			  <label class="text-success lead">Keterangan</label>
			  <input type="text" name="keterangan" class="form-control" value="<?=$bk["keterangan"]; ?>" required/>
	  		</div>
	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>
			<button onclick="goBack()">Batal</button>
<script>
function goBack() {
  window.history.back();
}
</script>
	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
	<footer>
            Copyright &copy; 2023 || by Muhamad Fauzi Permana SI M'U 2023
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>