 <?php 
//koneksi ke database
$conn = mysqli_connect("localhost","root","","perpus_20");

 function query($query){
 	global $conn;
	$result = mysqli_query($conn,$query);
	$rows = [];
	while ($row = mysqli_fetch_array($result)) {
	 	$rows[] = $row;
	} 
	return $rows;
}

function tambah($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_member = htmlspecialchars($data["id_member"]);
	$id_buku = htmlspecialchars($data["id_buku"]);
	$tgl_pinjam = htmlspecialchars($data["tgl_pinjam"]);
	$tgl_kembali = htmlspecialchars($data["tgl_kembali"]);
	$status = htmlspecialchars($data["status"]);
	
	//insert data ke dalam db
	$query = "INSERT INTO transaksi VALUES ('','$id_member','$id_buku','$tgl_pinjam','$tgl_kembali','$status')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
}

function hapus($id_transaksi){
	global $conn;
	mysqli_query($conn,"DELETE FROM transaksi WHERE id_transaksi='$id_transaksi'");
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_transaksi =$data["id_transaksi"];
	$id_member = htmlspecialchars($data["id_member"]);
	$id_buku = htmlspecialchars($data["id_buku"]);
	$tgl_pinjam = htmlspecialchars($data["tgl_pinjam"]);
	$tgl_kembali = htmlspecialchars($data["tgl_kembali"]);
	$status = htmlspecialchars($data["status"]);
	
	//update data ke dalam db
	$query = "UPDATE transaksi SET
					id_member='$id_member', 
					id_buku='$id_buku',
					tgl_pinjam='$tgl_pinjam',
					tgl_kembali='$tgl_kembali',
					status='$status'
			WHERE id_transaksi='$id_transaksi'
			";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);	
}

function cari($keyword){
	$query = "SELECT * FROM transaksi WHERE nama LIKE '%$keyword%' OR kode_buku LIKE '%$keyword%' OR judul_buku LIKE '%$keyword%' OR tgl_pinjam LIKE '%$keyword%' OR tgl_kembali LIKE '%$keyword%' OR status LIKE '%$keyword%'";
	return query($query);
}
?>