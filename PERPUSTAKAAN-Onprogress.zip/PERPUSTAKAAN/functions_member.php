<?php 
//koneksi ke database
$conn = mysqli_connect("localhost","root","","perpus_20");

 function query($query){
 	global $conn;
	$result = mysqli_query($conn,$query);
	$rows = [];
	while ($row = mysqli_fetch_array($result)) {
	 	$rows[] = $row;
	} 
	return $rows;
}

function tambah($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_member = htmlspecialchars($data["id_member"]);
	$NIS = htmlspecialchars($data["NIS"]);
	$nama = htmlspecialchars($data["nama"]);
	$jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
	$tempat_lahir = htmlspecialchars($data["tempat_lahir"]);
	$tgl_lahir = htmlspecialchars($data["tgl_lahir"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$no_telp = htmlspecialchars($data["no_telp"]);

	//insert data ke dalam db
	$query = "INSERT INTO member VALUES ('$id_member','$NIS','$nama','$jenis_kelamin','$tempat_lahir','$tgl_lahir','$alamat','$no_telp')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
}

function hapus($id_member){
	global $conn;
	mysqli_query($conn,"DELETE FROM member WHERE id_member='$id_member'");
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_member = htmlspecialchars($data["id_member"]);
	$NIS = htmlspecialchars($data["NIS"]);
	$nama = htmlspecialchars($data["nama"]);
	$jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
	$tempat_lahir = htmlspecialchars($data["tempat_lahir"]);
	$tgl_lahir = htmlspecialchars($data["tgl_lahir"]);
	$alamat = htmlspecialchars($data["alamat"]);
	$no_telp = htmlspecialchars($data["no_telp"]);
	//update data ke dalam db
	$query = "UPDATE member SET 
					id_member='$id_member
					NIS='$NIS',
					nama='$nama',
					jenis_kelamin='$jenis_kelamin',
					tempat_lahir='$tempat_lahir',
					tgl_lahir='$tgl_lahir',
				 	alamat='$alamat',
					no_telp='$no_telp',
			WHERE id_member='$id_member'
			";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);	
}

function cari($keyword){
	$query = "SELECT * FROM member WHERE id_member LIKE '%$keyword%' OR nama LIKE '%$keyword%' OR NIS LIKE '%$keyword%' OR no_telp LIKE '%$keyword%' OR tgl_lahir LIKE '%$keyword%'";
	return query($query);
}
?>