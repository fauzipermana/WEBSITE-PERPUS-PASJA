
<!DOCTYPE html>
<html>
<head>
	<title>contact</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="buku2.php">Buku</a></li>
                <li class="active"><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="title">
		 	<h1>Perpustakaan SMK Pasundan Jatinangor</h1>
		 </div>
	</header>

	<div class="container">
		<div class="card mt-3"> <!-- margin top=3 -->
			<div class="card-header bg-success text-white text-center lead">
	    		CONTACT INFO
	  		</div>
	  	<div class="card-body">
	  		<table class="table table-bordered table-striped">
		  		<tr class=" text-dark text-center">
		  			<th class="text-center" width="25%">Address</th>
		  			<th class="text-center" width="25%">E-mail</th>
		  			<th class="text-center" width="25%">Telp.</th>
		  			<th class="text-center" width="25%">Hp</th>
		  		</tr>
		  		<tr>
		  			<td class="text-center">Jl. Jalan Kolonel Ahmad Syam Jatinangor</td>
		  			<td class="text-center">Perpusdasukoharjo@gmail.com</td>
		  			<td class="text-center">0271-97252426</td>
		  			<td class="text-center">08363352252</td>
		  		</tr>
	  		</table>

			 <iframe src="https://www.google.com/maps/place/SMK+Pasundan+Jatinangor/@-6.9425544" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
		</div>
		</div>
	</div>

	<footer>
		Copyright &copy; 2023 || by Muhamad Fauzi Permana SI M'U 2023
    </footer>
 
</body>
</html>