
<!DOCTYPE html>
<html>
<head>
	<title>Perpustakaan Isdhian</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
    <header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo.gif"></div>
		 	<ul>
		 		<li class="active"><a href="home.php">Home</a></li>
                <li><a href="buku.php">Buku</a></li>
                <li><a href="member.php">Member</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=P_IuVVgds9k" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>Perpustakaan Kota Sukoharjo</h1>
		 </div>
	</header>

	<div class="menu-kiri">
            <div class="kotak">
				<h3>Berita Hits</h3>
 
                <nav class="menu-artikel">
                    <ul>
                        <li><a href="#">Perpustakaan Desa Dukuh Jawara Provinsi Jateng</a></li>
                        <li><a href="#">Dulu Memprihatinkan, Gedung Arpusda Sukoharjo Makin Cantik</a></li>
                        <li><a href="#">Liburan Sekolah, Pengunjung Perpustakaan Kota Solo Meningkat</a></li>
                    	<li><a href="#">Tingkatkan Minat Baca Anak Zaman Now, Sukoharjo Luncurkan Kafe Perpustakaan</a></li>
                    </ul>
                </nav>
            </div>

        </div>
 
        <div class="menu-tengah">
            <div class="kotak">
            	<table border="1" cellpadding="10" cellspacing="0">
					<tr><center><b>Buku Terbaruu</b></center></tr><br>
					<tr><center><img src="gambar/bukuterbaru.jpg"></center></tr><br>
					<tr><p align="justify">
						Nah, buat kamu yang masih mahasiswa awal, maka rekomendasi yang disarankan adalah mempelajari dasar-dasar informatika itu terlebih dahulu. Kamu bisa membaca buku ajar karya Novega Pratama Adiputra. Setidaknya di buku ini kamu akan berkenalan dan belajar tentang pengolahahan data, pemprosesan data, penyimpanan data, manipulasi data dan masih banyak lagi yang akan kamu pelajari di sana.<br>
					</tr><br>
					<tr>Dapatkan Sekarang !!!</tr><br>
				</table>
            </div>
        </div>
 
         <div class="menu-kanan">
            <div class="kotak">
                <h3>Buku Terpopuler</h3>
 
                <nav class="menu-artikel">
                    <ul>
                        <li><a href="#">Komet Minor by Tere Liye</a></li>
                        <li><a href="#">Dear Tomorrow by Maudy Ayunda</a></li>
                        <li><a href="#">Educated by Tara Westover</a></li>
                    </ul>
                </nav>
            </div>
        </div>

	<footer>
        Copyright &copy; 2020 || by Ismi Dzikrina Informatika
    </footer>

</body>
</html>