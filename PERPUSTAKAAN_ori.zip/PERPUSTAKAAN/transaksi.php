<?php
	require "functions_transaksi.php";
	$transaksi = query ("SELECT * FROM transaksi");


	//tekan tombol cari
	if (isset($_POST["cari"])) {
		$transaksi = cari($_POST["keyword"]);
	}
	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(tambah($_POST) > 0){
			echo "
					<script>
						alert('data berhasil ditambahkan');
						document.location.href='transaksi.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal ditambahkan');
						document.location.href='transaksi.php';
					</script>
			";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>transaksi</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">

</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="buku.php">Buku</a></li>
                <li><a href="member.php">Member</a></li>
                <li class="active"><a href="transaksi.php">Transaksi</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=P_IuVVgds9k" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>Perpustakaan Kota Sukoharjo</h1>
		 </div>
	</header>

	<div class="container">
	
	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-success text-white text-center lead">
	    FORM INPUT DATA TRANSAKSI PEMINJAMAN & PENGEMBALIAN
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		
	  		<div class="form-group">
	  			<label class="text-success lead">Id Member</label>
	  			<select class="form-control" name="id_member" required/>
					<?php 
						$sql = "SELECT * FROM member";
						$retval = mysqli_query($conn, $sql);
						while ($row = mysqli_fetch_array($retval)) {
							echo "<option value='$row[id_member]'> $row[id_member] </option>";
						}
					?>
				</select> 
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Id Buku</label>
	  			<select class="form-control" name="id_buku" required/>
					<?php 
						$sql = "SELECT * FROM buku";
						$retval = mysqli_query($conn, $sql);
						while ($row = mysqli_fetch_array($retval)) {
							echo "<option value='$row[id_buku]'> $row[id_buku] </option>";
						}
					?>
				</select> 
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Tanggal Peminjaman</label>
	  			<input type="date" name="tgl_pinjam" class="form-control" required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="text-success lead">Tanggal Kembalian</label>
	  			<input type="date" name="tgl_kembali" class="form-control">
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Status</label>
	  			<input type="text" name="status" class="form-control" placeholder="Masukkan status peminjaman disini..." required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>
	  		<button type="reset" class="btn btn-danger" name="reset">Kosongkan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->

	<!-- pencarian -->
	<form action="#" method="post">
		<div class="input-group mb-3"> 
		<input type="text" name="keyword" size="40" autofocus placeholder="Masukkan kata pencarian..." autocomplete="off" id="keyword" class="form-control">
			<div class="input-group-append">
				<button type="submit" name="cari" id="tombolcari" class="btn btn-warning">Cari</button>
			</div>
		</div>
	</form>

	<!-- cetak -->
	<a href="cetak.php" class="btn btn-primary">Cetak</a>

	<!-- awalcard tabel .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header text-white bg-success text-center lead">
	    DATA TRANSAKSI PEMINJAMAN & PENGEMBALIAN
	  </div>
	  <div class="card-body">
	  	<table class="table table-bordered table-striped">
	  		<tr class=" text-dark text-center">
	  			<th class="text-center">No</th>
	  			<th class="text-center">Id Member</th>
	  			<th class="text-center">Id Buku</th>
	  			<th class="text-center">Tanggal Pinjam</th>
	  			<th class="text-center">Tanggal Kembali</th>
	  			<th class="text-center">Status</th>
	  			<th class="text-center">Aksi</th>
	  		</tr>
	  		<?php $i = 1; ?>
	  		<?php foreach ($transaksi as $row) :	?> 
	  		<tr>
	  			<td><?=$i; ?></td>
	  			<td><?=$row['id_member']?></td>
	  			<td><?=$row["id_buku"]?></td>
	  			<td><?=$row["tgl_pinjam"]?></td>
	  			<td><?=$row["tgl_kembali"]?></td>
	  			<td><?=$row["status"]?></td>
	  			<td>
	  				<a href="edit_transaksi.php?id_transaksi=<?= $row["id_transaksi"];?>" class="btn btn-warning">Edit</a>
	  				<a href="hapus_transaksi.php?id_transaksi=<?=$row["id_transaksi"];?>"onclick="return confirm('apakah anda ingin menghapus data ?')" class="btn btn-danger">Hapus</a>
	  			</td>
	  		</tr>
	  		<?php $i++;?>
	  		<?php endforeach; ?>
	  	</table>
	  </div>
	</div>
	<!-- selesai card tabel -->
	</div>
	<footer>
		Copyright &copy; 2020 || by Ismi Dzikrina Informatika
    </footer>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>