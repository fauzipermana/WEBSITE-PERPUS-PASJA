<?php 
//koneksi ke database
$conn = mysqli_connect("localhost","root","","perpus_20");

 function query($query){
 	global $conn;
	$result = mysqli_query($conn,$query);
	$rows = [];
	while ($row = mysqli_fetch_array($result)) {
	 	$rows[] = $row;
	} 
	return $rows;
}

function tambah($data){
	global $conn;
	//ambil semua data yang dikirim
	// $kode_buku = htmlspecialchars($data["kode_buku"]);
	$judul_buku = htmlspecialchars($data["judul_buku"]);
	$penulis_buku = htmlspecialchars($data["penulis_buku"]);
	$penerbit_buku = htmlspecialchars($data["penerbit_buku"]);
	$tahun_terbit = htmlspecialchars($data["tahun_terbit"]);
	$stok = htmlspecialchars($data["stok"]);

	//insert data ke dalam db
	$query = "INSERT INTO buku VALUES ('','$judul_buku','$penulis_buku','$penerbit_buku','$tahun_terbit','$stok')";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);
}

function hapus($id_buku){
	global $conn;
	mysqli_query($conn,"DELETE FROM buku WHERE id_buku='$id_buku'");
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	//ambil semua data yang dikirim
	$id_buku =$data["id_buku"];
	$judul_buku = htmlspecialchars($data["judul_buku"]);
	$penulis_buku = htmlspecialchars($data["penulis_buku"]);
	$penerbit_buku = htmlspecialchars($data["penerbit_buku"]);
	$tahun_terbit = htmlspecialchars($data["tahun_terbit"]);
	$stok = htmlspecialchars($data["stok"]);

	//update data ke dalam db
	$query = "UPDATE buku SET 
					judul_buku='$judul_buku',
					penulis_buku='$penulis_buku',
					penerbit_buku='$penerbit_buku',
					tahun_terbit='$tahun_terbit',
					stok='$stok'
			WHERE id_buku='$id_buku'
			";
	mysqli_query($conn,$query);
	return mysqli_affected_rows($conn);	
}

function cari($keyword){
	$query = "SELECT * FROM buku WHERE id_buku LIKE '%$keyword%' OR judul_buku LIKE '%$keyword%' OR penulis_buku LIKE '%$keyword%' OR penerbit_buku LIKE '%$keyword%' OR tahun_terbit LIKE '%$keyword%' OR stok LIKE '%$keyword%'";
	return query($query);
}
?>