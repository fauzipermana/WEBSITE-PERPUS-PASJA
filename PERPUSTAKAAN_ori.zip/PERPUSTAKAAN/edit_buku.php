<?php
	require "functions_buku.php";
	$id_buku = $_GET["id_buku"];
	$bk = query("SELECT * FROM buku WHERE id_buku=$id_buku")[0];

	$query = "SELECT * FROM buku";
	$result = mysqli_query($conn,$query);

	//cek tombol submit sudan ditekan apa belum
	if (isset($_POST['submit'])) {
	
		//cek jika data berhasil ditambahkan ,>0 artinya ada baris data yang berubah didb
		if(edit($_POST) > 0){
			echo "
					<script>
						alert('data berhasil diedit');
						document.location.href='buku.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal diedit');
						document.location.href='buku.php';
					</script>
			";
		}
		}
?>
<!-- //  -->
<!DOCTYPE html>
<html>
<head>
	<title>buku</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<div class="container">

	<!-- awalcard form .. -->
	<div class="card mt-3"> <!-- margin top=3 -->
	  <div class="card-header bg-success text-white text-center lead">
	    FORM EDIT DATA BUKU
	  </div>
	  <div class="card-body">
	  	<form method="post" action="">
	  		<input type="hidden" name="id_buku" value="<?=$bk["id_buku"]; ?>">
	  		<div class="form-group">
	  			<label class="text-success lead">Id Buku</label>
	  			<input type="text" name="id_buku" class="form-control" readonly value="<?=$bk["id_buku"];?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Judul Buku</label>
	  			<input type="text" name="judul_buku" class="form-control" value="<?=$bk["judul_buku"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Penulis Buku</label>
	  			<input type="text" name="penulis_buku" class="form-control" value="<?=$bk["penulis_buku"]; ?>" required/>
	  		</div>  
	  		<div class="form-group">
	  			<label class="text-success lead">Penerbit</label>
	  			<input type="text" name="penerbit_buku" class="form-control" value="<?=$bk["penerbit_buku"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Tahun Terbit</label>
	  			<input type="number" name="tahun_terbit" min="2000" max="2020" class="form-control" value="<?=$bk["tahun_terbit"]; ?>" required/>
	  		</div>
	  		<div class="form-group">
	  			<label class="text-success lead">Stok</label>
	  			<input type="number" name="stok" min="0" max="50" class="form-control" value="<?=$bk["stok"]; ?>" required/>
	  		</div>

	  		<button type="submit" class="btn btn-success" name="submit">Simpan</button>

	  	</form>
	  </div>
	</div>
	<!-- selesai card form -->
	</div>
	<footer>
            Copyright &copy; 2020 || by Ismi Dzikrina Informatika
    </footer>

<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>