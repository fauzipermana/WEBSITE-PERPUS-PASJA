<?php
//cek untuk tombol hapus
	require "functions_buku.php";
	$id_buku=$_GET["id_buku"];
	if (hapus($id_buku)>0) {
		echo "
					<script>
						alert('data berhasil dihapus');
						document.location.href='buku.php';
					</script>
			";
		}else{
			echo "
					<script>
						alert('data gagal dihapus');
						document.location.href='buku.php';
					</script>
			";
	}

?>