
<!DOCTYPE html>
<html>
<head>
	<title>about</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
	<header>
		 <div class="main">
		 	<div class="logo"><img src="gambar/logo.gif"></div>
		 	<ul>
		 		<li><a href="home.php">Home</a></li>
		 		<li><a href="buku.php">Buku</a></li>
                <li><a href="member.php">Member</a></li>
                <li><a href="transaksi.php">Transaksi</a></li>
                <li class="active"><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
		 	</ul>
		 </div>
		 <div class="button">
		 	<a href="https://www.youtube.com/watch?v=P_IuVVgds9k" class="btn1">Tonton Video</a>
		 	<a href="index.php" class="btn2">Logout</a>
		 </div>
		 <div class="title">
		 	<h1>Perpustakaan Kota Sukoharjo</h1>
		 </div>
	</header>

	<div class="container">
		<div class="card mt-3"> <!-- margin top=3 -->
			<div class="card-header bg-success text-white text-center lead">
	    		ABOUT US
	  		</div>
	  	<div class="card-body">
	  		<table class="table table-bordered table-striped">
		  		<tr class=" text-dark text-center">
		  			<th class="text-center" width="33.3%">Ismi Dzikrina</th>
		  		</tr>
		  		<tr>
		  			<td class="text-center"><img src="gambar/ismi.jpg" height="300px" width="auto"></td>	
		  		</tr>
		  		<tr>
		  			<td class="text-center">L200180010</td>
		  		</tr>
		  		<tr>
		  			<td class="text-center">Informatika UMS</td>	
		  		</tr>
	  		</table>
		</div>
		</div>
	</div>

	<footer>
            Copyright &copy; 2020 || by Ismi Dzikrina Informatika
    </footer>
 



</body>
</html>